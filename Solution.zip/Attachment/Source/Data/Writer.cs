﻿namespace VRP.VRPTW.Data
{
    class Writer
    {
    }
}
